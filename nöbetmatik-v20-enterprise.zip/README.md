# Nöbetmatik v20 Enterprise Edition

**Nöbetmatik v20**, hastaneler ve sağlık kurumları için geliştirilmiş; kıdem, grup dengesi, nöbet sayısı hedefleri ve özel kısıtlamaları (off günleri, istekler) dikkate alarak **Monte Carlo Simülasyonu** ile en adil nöbet listesini oluşturan web tabanlı bir otomasyon sistemidir.

![Version](https://img.shields.io/